package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value = "/cv")
public class Controlador {

    Cita nueva = new Cita();

  /*  public void registrar(){
        nueva.setCliente();
        nueva.setCorreo();
        nueva.setTelefono();
        nueva.setDoctor();
        nueva.setHora();
        nueva.setFecha();
        nueva.setAsunto();
    } */

    @GetMapping("/datos")
    public String obtenerDatos(Model model){
        nueva.getCliente();
        nueva.getCorreo();
        nueva.getAsunto();
        nueva.getDoctor();
        nueva.getHora();
        nueva.getFecha();
        nueva.getAsunto();

        model.addAttribute("cv", nueva);
        return "cv";
    }
}
